#include "TeenyKeyboard.h"
typedef TeenyKeyboardDevice CocoMidi;