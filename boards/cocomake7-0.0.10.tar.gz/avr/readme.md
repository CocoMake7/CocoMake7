
[![Build Status](https://travis-ci.org/CocoMake7/CocoMake7Packager.svg?branch=master)](https://travis-ci.org/CocoMake7/CocoMake7Packager)

lets organize this later..

directory structure

avr \
	\libraries
	\cores
	\tools
	\variants


