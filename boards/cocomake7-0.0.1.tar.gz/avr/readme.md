lets organize this later..

directory structure

avr \
	\libraries
	\cores
	\tools
	\variants


