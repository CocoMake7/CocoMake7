#include "TeenyKeyboard.h"
#define CocoKeyboard TeenyKeyboard